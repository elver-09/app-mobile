import 'dart:io';
import 'package:flutter/material.dart';

class DeliveryPhotosWidget extends StatelessWidget {
  final List<File> photos;
  final int maxPhotos;
  final VoidCallback? onTakePhoto;
  final VoidCallback onViewPhotos;
  final Function(int) onRemovePhoto;

  const DeliveryPhotosWidget({
    super.key,
    required this.photos,
    required this.maxPhotos,
    this.onTakePhoto,
    required this.onViewPhotos,
    required this.onRemovePhoto,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFFFFFFF),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(
                child: Text(
                  'Evidencia de entrega',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF0F172A),
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              const SizedBox(width: 8),
              const Flexible(
                child: Text(
                  'Obligatoria para finalizar',
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontSize: 11,
                    color: Color(0xFF94A3B8),
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Center(
            child: _buildPhotoGrid(context),
          ),
          const SizedBox(height: 10),
          if (photos.isNotEmpty)
            Center(
              child: OutlinedButton.icon(
                onPressed: onViewPhotos,
                icon: const Icon(Icons.photo_library_outlined, size: 16),
                label: const Text(
                  'Ver fotos',
                  style: TextStyle(fontSize: 12),
                ),
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  side: const BorderSide(color: Color(0xFF1D4ED8)),
                  foregroundColor: const Color(0xFF1D4ED8),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildPhotoGrid(BuildContext context) {
    final photoBoxes = List.generate(
      maxPhotos,
      (index) => SizedBox(
        width: 132,
        child: _buildPhotoBox(context, index),
      ),
    );

    if (maxPhotos <= 2) {
      return Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          for (int i = 0; i < photoBoxes.length; i++) ...[
            if (i > 0) const SizedBox(width: 8),
            photoBoxes[i],
          ],
        ],
      );
    }

    if (maxPhotos == 3) {
      return Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              photoBoxes[0],
              const SizedBox(width: 8),
              photoBoxes[1],
            ],
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [photoBoxes[2]],
          ),
        ],
      );
    }

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      alignment: WrapAlignment.center,
      children: photoBoxes,
    );
  }

  Widget _buildPhotoBox(BuildContext context, int index) {
    final hasPhoto = index < photos.length;

    return AspectRatio(
      aspectRatio: 1,
      child: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFFF8FAFC),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: const Color(0xFFE2E8F0)),
              image: hasPhoto
                  ? DecorationImage(
                      image: FileImage(photos[index]),
                      fit: BoxFit.cover,
                    )
                  : null,
            ),
            child: hasPhoto
                ? null
                : const Center(
                    child: Icon(
                      Icons.add_photo_alternate_outlined,
                      size: 26,
                      color: Color(0xFF94A3B8),
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}
